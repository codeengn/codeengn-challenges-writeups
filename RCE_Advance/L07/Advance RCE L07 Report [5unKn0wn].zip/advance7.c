#include <stdio.h>

void decipher(unsigned int* v, unsigned int* key, unsigned int delta, unsigned int x)
{
	delta ^= x;
	unsigned int round = 32;
	unsigned int v0 = v[0];
	unsigned int v1 = v[1];
	unsigned int sum = delta << 5;
	while (round--)
	{
		v1 -= ((((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum >> 11) & 3]));
		sum -= delta;
		v0 -= ((((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]));
	}
	v[0] = v0;
	v[1] = v1;
}

int main(void)
{
	int cnt = 0;
	unsigned int hashCode = 0x9e1e73d5;	// from C#
	for (unsigned long int i = 33; i < 0x100000000; i += 57) {
		unsigned int v[] = {0x28BF522F, 0xA5BE61D1};
		unsigned int key[] = {0x408112F1, 0x1A3B0B51, 0x2957C9FD, 0x1B327D1D};
		decipher(v, key, 0x8ffe2225, 0x8ffe2225 ^ i);
		if (v[0] == 0xB4E4E0D5 && v[1] == hashCode) {	// 0xB4E4E0D5 is crc32 of "CodeEngn", poly is 0xbaadf00d
			printf("\nanswer is %08X\n", i ^ hashCode ^ 0x8ffe2225);	// 11E051D1
			break;
		}
		if (cnt % 0x10000 == 0) {
			printf("%x\n", cnt);
		}
		cnt += 1;
	}

	return 0;
}